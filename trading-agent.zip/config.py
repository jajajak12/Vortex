# ============================================================
# TRADING AGENT - CONFIG
# Strategy 1: Fresh Liquidity Grab + Rejection
# ============================================================

# --- TELEGRAM ---
TELEGRAM_BOT_TOKEN = "YOUR_BOT_TOKEN"
TELEGRAM_CHAT_ID   = "YOUR_CHAT_ID"

# --- BINANCE ---
BINANCE_API_KEY    = "YOUR_BINANCE_API_KEY"
BINANCE_API_SECRET = "YOUR_BINANCE_API_SECRET"

# --- PAIRS TO SCAN (Crypto) ---
CRYPTO_PAIRS = [
    "BTCUSDT", "ETHUSDT", "SOLUSDT", "BNBUSDT",
    "XRPUSDT", "ADAUSDT", "DOGEUSDT", "AVAXUSDT",
    "DOTUSDT", "LINKUSDT", "MATICUSDT", "LTCUSDT",
    "ATOMUSDT", "UNIUSDT", "NEARUSDT"
]

# --- STRATEGY PARAMETERS ---
LIQUIDITY_CANDLES_MIN   = 10      # Minimum 4H candles untouched = "fresh"
SWING_LOOKBACK          = 50      # Candles lookback untuk cari swing high/low di 4H
TOUCH_THRESHOLD_PCT     = 0.003   # 0.3% — toleransi "menyentuh" zona
VOLUME_SPIKE_MULTIPLIER = 1.5     # Volume spike = 1.5x rata-rata 20 candle terakhir

# --- TIMEFRAMES ---
TF_ZONE    = "4h"    # Untuk identifikasi zona liquidity
TF_MONITOR = "30m"   # Untuk deteksi touch
TF_ENTRY   = "5m"    # Untuk konfirmasi rejection

# --- SCANNER INTERVAL ---
SCAN_INTERVAL_SECONDS = 60  # Scan setiap 60 detik
